//
//  ViewController.swift
//  PodsFeed
//
//  Created by iOS on 7/20/15.
//  Copyright (c) 2015 iOS. All rights reserved.
//

import UIKit
import SafariServices

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var contentTableView: UITableView!
    var indexes : Set<Int> = []
    
  

    var content : [DataControl.Entry] = []
    
    
    //Initialization Methods
    override func viewDidLoad() {
         super.viewDidLoad()
    
        self.contentTableView.estimatedRowHeight = 100
        self.contentTableView.rowHeight = UITableViewAutomaticDimension
        
        content = DataControl.loadData()
    }
    
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        self.contentTableView.reloadData()
        self.contentTableView.reloadSections(NSIndexSet(index: 0), withRowAnimation: .Automatic)

        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        self.contentTableView.reloadSections(NSIndexSet(index: 0), withRowAnimation: .Automatic)
    }


    

    
    // Table View Methods
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return self.content.count
        
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        UIApplication.sharedApplication().openURL(NSURL(string: self.content[indexPath.row].link)!)
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
    }
    
    func tableView(tableView: UITableView, editActionsForRowAtIndexPath indexPath: NSIndexPath) -> [AnyObject]? {
        var favoriteAction : UITableViewRowAction
        if (self.indexes.indexOf(indexPath.row) == nil)
        {
            favoriteAction = UITableViewRowAction(style: UITableViewRowActionStyle.Default, title: "Favorite") { (action, index) -> Void in
                    tableView.editing = false
                    tableView.cellForRowAtIndexPath(indexPath)?.backgroundColor = UIColor.yellowColor()
                    self.indexes.insert(indexPath.row)
            
                }
        
            favoriteAction.backgroundColor = UIColor.greenColor()
        }
        else
        {
            favoriteAction = UITableViewRowAction(style: UITableViewRowActionStyle.Default, title: "Unfavorite") { (action, index) -> Void in
                tableView.editing = false
                tableView.cellForRowAtIndexPath(indexPath)?.backgroundColor = UIColor.whiteColor()
                self.indexes.remove(indexPath.row)
                
            }
            
            favoriteAction.backgroundColor = UIColor.redColor()
            
        }
        
        
        var addAtList = UITableViewRowAction(style: UITableViewRowActionStyle.Default, title: "Add to Reading List") { (action, IndexingGenerator) -> Void in
            
            
            let url = NSURL(string: self.content[indexPath.row].link)
            let list = SSReadingList.defaultReadingList()
            list.addReadingListItemWithURL(url, title: nil, previewText: nil, error: nil)
            self.tableView(self.contentTableView, didSelectRowAtIndexPath: indexPath)
            
        }
        addAtList.backgroundColor = UIColor.blueColor()
        

        return [favoriteAction,addAtList]
        
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        
        
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("customCell", forIndexPath: indexPath) as! UITableViewCell
        let newCell = cell as! CustomCell

        
        if (self.indexes.indexOf(indexPath.row) == nil)
        {
          
            newCell.backgroundColor = UIColor.whiteColor()
        }
        else
        {
          
            newCell.backgroundColor = UIColor.yellowColor()
            
        }
       
        newCell.titleLabel.text = self.content[indexPath.row].title
        newCell.informationLabel.text = self.content[indexPath.row].contentSnippet.componentsSeparatedByString("\n").first
        if self.content[indexPath.row].publishedDate.description.componentsSeparatedByString(" ").first == NSDate().description.componentsSeparatedByString(" ").first
        {
            newCell.titleLabel.textColor = UIColor.blueColor()
            newCell.informationLabel.textColor = UIColor.blueColor()
        }
        else
        {newCell.titleLabel.textColor = UIColor.blackColor()
            newCell.informationLabel.textColor = UIColor.blackColor()
            
        }
        

        
        return newCell
        
    }
    
    
       

}

