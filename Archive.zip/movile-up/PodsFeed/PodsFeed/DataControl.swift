//
//  DataControl.swift
//  PodsFeed
//
//  Created by iOS on 7/21/15.
//  Copyright (c) 2015 iOS. All rights reserved.
//

import Foundation

class DataControl {

    
    
    struct Entry {
        let content : String
        let contentSnippet : String
        let link : String
        let publishedDate : NSDate
        let title : String
        
        
        static func decode(j : AnyObject) -> Entry?
        {
            if let entryData  = j as? NSDictionary
            {
                
                /* NSDateFormatter *df = [[NSDateFormatter alloc] init];
                [df setDateFormat:@"yyyy-MM-dd HH:mm:ss a"];
                NSDate *myDate = [df dateFromString: myDateAsAStringValue];
                // entryData["publishedDate"] as! String
                */
                let format = NSDateFormatter()
                format.dateFormat = "EEE, d MMM yyyy HH:mm:ss Z"
                let date = format.dateFromString(entryData["publishedDate"] as! String)
                return Entry(content: entryData["content"] as! String, contentSnippet: entryData["contentSnippet"] as! String, link: entryData["link"] as! String, publishedDate: date! , title: entryData["title"] as! String)
                
            }
            
            
            return nil
        }
        
        
    }
    
    

    static func loadData() -> [Entry]
    {
        var content :[Entry] = []
        var error: NSError?
        let path = NSBundle.mainBundle().pathForResource("new-pods", ofType: "json")!
        let json : NSData = NSData(contentsOfFile: path, options: NSDataReadingOptions.DataReadingMappedIfSafe, error: nil)!
        let jsondict = NSJSONSerialization.JSONObjectWithData(json, options: nil, error: nil) as! NSDictionary
        //print(jsondict)
        if let responseData = jsondict["responseData"] as? NSDictionary
        {
            if let feed = responseData["feed"] as? NSDictionary
            {
                
                if let entries = feed["entries"] as? NSArray
                {
                    for entry in entries
                    {
                        let object : Entry = Entry.decode(entry)!
                        content.append(object)
                    }
                    
                }
                
                
            }
        }
     
        return content
    }
}
